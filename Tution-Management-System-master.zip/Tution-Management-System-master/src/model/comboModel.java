package model;
public class comboModel{
    private String Name;
     public comboModel(){
        
    }
    public comboModel(String Name){
        this.Name=Name;
    }
    public void setName(String Name){
		this.Name=Name;
	}
	public String getName(){
		return Name;
	}	
}